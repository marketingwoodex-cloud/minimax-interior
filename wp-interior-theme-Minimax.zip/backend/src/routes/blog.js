import { Router } from "express";
import { v4 as uuid } from "uuid";
import { findAll, findById, getMemory } from "../store.js";
import { authRequired, authRole } from "../middleware.js";

const router = Router();
router.use(authRequired);
router.use(authRole("admin", "editor"));

router.get("/", async (req, res) => {
  try {
    const { category, status, search } = req.query;
    let items = await findAll("BlogPost", {}, "blogPosts");
    if (category) items = items.filter((i) => i.category === category);
    if (status) items = items.filter((i) => i.status === status);
    if (search) {
      const s = search.toLowerCase();
      items = items.filter((i) => `${i.title} ${i.excerpt}`.toLowerCase().includes(s));
    }
    res.json({ posts: items });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

router.get("/:id", async (req, res) => {
  try {
    const p = await findById("BlogPost", req.params.id, "blogPosts");
    if (!p) return res.status(404).json({ error: "Not found" });
    res.json({ post: p });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

router.post("/", async (req, res) => {
  try {
    const all = getMemory();
    if (!all.blogPosts) all.blogPosts = [];
    const id = uuid();
    const newPost = {
      _id: id,
      id: req.body.slug || id,
      ...req.body,
      status: req.body.status || "draft",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    all.blogPosts.push(newPost);
    res.status(201).json({ post: newPost });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

router.put("/:id", async (req, res) => {
  try {
    const all = getMemory();
    const idx = all.blogPosts?.findIndex((p) => p._id === req.params.id || p.id === req.params.id);
    if (idx === -1) return res.status(404).json({ error: "Not found" });
    all.blogPosts[idx] = { ...all.blogPosts[idx], ...req.body, updatedAt: new Date().toISOString() };
    res.json({ post: all.blogPosts[idx] });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

router.delete("/:id", async (req, res) => {
  try {
    const all = getMemory();
    const idx = all.blogPosts?.findIndex((p) => p._id === req.params.id || p.id === req.params.id);
    if (idx === -1) return res.status(404).json({ error: "Not found" });
    const [removed] = all.blogPosts.splice(idx, 1);
    res.json({ ok: true, post: removed });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

export { router as blogRouter };
