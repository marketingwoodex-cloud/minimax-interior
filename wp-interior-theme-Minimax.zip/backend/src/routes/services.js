import { Router } from "express";
import { findAll, findById, getMemory } from "../store.js";
import { authRequired, authRole } from "../middleware.js";

const router = Router();
router.use(authRequired);
router.use(authRole("admin", "editor"));

router.get("/", async (_req, res) => {
  try {
    const items = await findAll("Service", {}, "services");
    res.json({ services: items });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

router.get("/:id", async (req, res) => {
  try {
    const s = await findById("Service", req.params.id, "services");
    if (!s) return res.status(404).json({ error: "Not found" });
    res.json({ service: s });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

router.put("/:id", async (req, res) => {
  try {
    const all = getMemory();
    const idx = all.services?.findIndex((s) => s._id === req.params.id || s.id === req.params.id || s.slug === req.params.id);
    if (idx === -1) return res.status(404).json({ error: "Not found" });
    all.services[idx] = { ...all.services[idx], ...req.body, updatedAt: new Date().toISOString() };
    res.json({ service: all.services[idx] });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

export { router as servicesRouter };
