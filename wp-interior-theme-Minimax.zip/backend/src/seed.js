/**
 * Database seeding
 * Populates initial data on first run
 */

import { getMemory, isMongo, getDefaultSettings, getDefaultTheme, getDefaultHeaderFooter } from "./store.js";
import bcrypt from "bcryptjs";
import { v4 as uuid } from "uuid";

export async function seedDatabase() {
  const all = getMemory();

  // ============= USERS =============
  if (!all.users || all.users.length === 0) {
    const adminHash = await bcrypt.hash("wpinterior2024", 10);
    const editorHash = await bcrypt.hash("editor2025", 10);
    const demoHash = await bcrypt.hash("demo123", 10);
    all.users = [
      {
        _id: uuid(),
        id: "u-1",
        username: "admin",
        email: "admin@wpinterior.com",
        passwordHash: adminHash,
        fullName: "Elena Marchetti",
        role: "admin",
        createdAt: "2025-01-01",
      },
      {
        _id: uuid(),
        id: "u-2",
        username: "editor",
        email: "editor@wpinterior.com",
        passwordHash: editorHash,
        fullName: "Hassan Raza",
        role: "editor",
        createdAt: "2025-01-15",
      },
      {
        _id: uuid(),
        id: "u-3",
        username: "demo",
        email: "demo@wpinterior.com",
        passwordHash: demoHash,
        fullName: "Demo User",
        role: "viewer",
        createdAt: "2025-02-01",
      },
    ];
    console.log("[seed] Created 3 users (admin/editor/demo)");
  }

  // ============= AGENTS =============
  if (!all.agents || all.agents.length === 0) {
    all.agents = [
      { _id: uuid(), id: uuid(), name: "Hassan Raza", email: "hassan@wpinterior.com", phone: "+92 300 1234567", role: "lead-agent", whatsappNumber: "923001234567", isOnline: true, specialties: ["Office Design", "Commercial"] },
      { _id: uuid(), id: uuid(), name: "Aaliyah Bennett", email: "aaliyah@wpinterior.com", phone: "+92 321 9876543", role: "senior-agent", whatsappNumber: "923219876543", isOnline: true, specialties: ["Residential", "3D Visualization"] },
      { _id: uuid(), id: uuid(), name: "Sara Ahmed", email: "sara@wpinterior.com", phone: "+92 333 1112233", role: "senior-agent", whatsappNumber: "923331112233", isOnline: false, specialties: ["Restaurant", "Cafe"] },
      { _id: uuid(), id: uuid(), name: "Elena Marchetti", email: "elena@wpinterior.com", phone: "+92 300 9998877", role: "manager", whatsappNumber: "923009998877", isOnline: true, specialties: ["All"] },
    ];
    console.log("[seed] Created 4 agents");
  }

  // ============= PAGES =============
  if (!all.pages || all.pages.length === 0) {
    all.pages = [
      { _id: "p-home", id: "p-home", slug: "home", title: "Home", description: "Main landing page", isHome: true, isPublished: true, blocks: [], meta: { title: "WP Interior Studio", description: "Interior design company Pakistan" }, order: 0 },
      { _id: "p-about", id: "p-about", slug: "about", title: "About", description: "About the studio", isHome: false, isPublished: true, blocks: [], meta: { title: "About WP Interior", description: "Our story" }, order: 1 },
      { _id: "p-services", id: "p-services", slug: "services", title: "Services", description: "All services", isHome: false, isPublished: true, blocks: [], meta: { title: "Services", description: "All services" }, order: 2 },
      { _id: "p-studio", id: "p-studio", slug: "studio", title: "3D Studio", description: "3D visualization", isHome: false, isPublished: true, blocks: [], meta: { title: "3D Studio", description: "Visualization" }, order: 3 },
      { _id: "p-portfolio", id: "p-portfolio", slug: "portfolio", title: "Portfolio", description: "Selected work", isHome: false, isPublished: true, blocks: [], meta: { title: "Portfolio", description: "Selected work" }, order: 4 },
      { _id: "p-journal", id: "p-journal", slug: "blog", title: "Journal", description: "Articles", isHome: false, isPublished: true, blocks: [], meta: { title: "Journal", description: "Articles" }, order: 5 },
      { _id: "p-contact", id: "p-contact", slug: "contact", title: "Contact", description: "Contact form", isHome: false, isPublished: true, blocks: [], meta: { title: "Contact", description: "Get in touch" }, order: 6 },
      { _id: "p-consultation", id: "p-consultation", slug: "consultation", title: "Free Consultation", description: "Book free consultation", isHome: false, isPublished: true, blocks: [], meta: { title: "Free Consultation", description: "Book free" }, order: 7 },
    ];
    console.log("[seed] Created 8 pages");
  }

  // ============= PROJECTS =============
  if (!all.projects || all.projects.length === 0) {
    all.projects = [
      { _id: uuid(), id: 1, title: "Linen & Stone Residence", category: "Residential", categorySlug: "residential", client: "Private Client", location: "Lahore, Pakistan", year: "2024", image: "https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?w=800&q=80", description: "A calm residential retreat.", status: "published" },
      { _id: uuid(), id: 2, title: "Atelier 9 Office", category: "Commercial", categorySlug: "commercial", client: "Atelier 9", location: "Dubai, UAE", year: "2024", image: "https://images.unsplash.com/photo-1497366216548-37526070297c?w=800&q=80", description: "Modern office design.", status: "published" },
      { _id: uuid(), id: 3, title: "Coastal Villa Retreat", category: "Residential", categorySlug: "residential", client: "Private Client", location: "Mykonos, Greece", year: "2023", image: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800&q=80", description: "Mediterranean elegance.", status: "published" },
    ];
    console.log("[seed] Created 3 projects");
  }

  // ============= BLOG POSTS =============
  if (!all.blogPosts || all.blogPosts.length === 0) {
    all.blogPosts = [
      {
        _id: uuid(),
        id: "office-interior-design-cost-lahore-2025",
        slug: "office-interior-design-cost-lahore-2025",
        title: "How Much Does Office Interior Design Cost in Lahore in 2025?",
        metaTitle: "Office Interior Design Cost Lahore 2025 · Real Numbers",
        metaDescription: "Detailed breakdown of office interior design costs in Lahore for 2025.",
        excerpt: "Pricing transparency matters. Here's exactly what office interior design costs in Lahore in 2025.",
        body: "<p>Pricing transparency matters...</p>",
        category: "Office Design",
        date: "Mar 18, 2025",
        readTime: "8 min",
        image: "https://images.unsplash.com/photo-1497366216548-37526070297c?w=1200&q=80",
        author: "Hassan Raza",
        authorRole: "Senior Designer",
        authorBio: "Hassan leads our commercial studio.",
        status: "published",
      },
    ];
    console.log("[seed] Created 1 blog post");
  }

  // ============= SERVICES =============
  if (!all.services || all.services.length === 0) {
    all.services = [
      { _id: uuid(), id: "office-interior-design-lahore", slug: "office-interior-design-lahore", name: "Office Interior Design", shortDescription: "Workplaces that boost productivity.", description: "Premium office design in Lahore.", icon: "commercial", category: "commercial", order: 0, price: "PKR 1.5M+", status: "published" },
      { _id: uuid(), id: "restaurant-interior-design-pakistan", slug: "restaurant-interior-design-pakistan", name: "Restaurant Interior Design", shortDescription: "Atmospheres guests remember.", description: "Restaurant design across Pakistan.", icon: "hospitality", category: "hospitality", order: 1, price: "PKR 2M+", status: "published" },
      { _id: uuid(), id: "3d-visualization-interior-design-pakistan", slug: "3d-visualization-interior-design-pakistan", name: "3D Visualization", shortDescription: "See it before it's built.", description: "Photorealistic 3D rendering.", icon: "3d", category: "3d", order: 2, price: "PKR 18K+", status: "published" },
    ];
    console.log("[seed] Created 3 services");
  }

  // ============= LEADS =============
  if (!all.leads || all.leads.length === 0) {
    all.leads = [
      { _id: uuid(), id: uuid(), name: "Aaliya Khan", email: "aaliya@example.com", phone: "+92 300 1234567", service: "Office Interior Design", message: "Hi, I'm interested in office design for our 8,000 sq ft space in Gulberg.", status: "new", createdAt: "2025-03-18T09:30:00Z" },
      { _id: uuid(), id: uuid(), name: "Hamza Sheikh", email: "hamza@cafeblue.pk", phone: "+92 321 9876543", service: "Cafe Interior Design", message: "We're launching a specialty cafe in DHA Phase 5.", status: "read", createdAt: "2025-03-17T14:22:00Z" },
    ];
    console.log("[seed] Created 2 leads");
  }

  // ============= CONVERSATIONS =============
  if (!all.conversations || all.conversations.length === 0) {
    all.conversations = [
      {
        _id: uuid(), id: uuid(),
        channel: "whatsapp", customerName: "Aaliya Khan", customerPhone: "+92 300 1234567", service: "Office Interior Design",
        status: "active", priority: "high", assignedAgent: all.agents?.[0]?.id,
        messages: [
          { id: uuid(), from: "customer", text: "Hi, I'm interested in office design for our 8,000 sq ft space in Gulberg.", timestamp: "2025-03-18T09:30:00Z", read: true },
          { id: uuid(), from: "agent", text: "Hi Aaliya! Thanks for reaching out. Could you share some reference images and your timeline?", timestamp: "2025-03-18T09:35:00Z", read: true },
        ],
        source: "contact-form", createdAt: "2025-03-18T09:30:00Z", updatedAt: "2025-03-18T09:40:00Z",
      },
    ];
    console.log("[seed] Created 1 conversation");
  }

  // ============= MEDIA =============
  if (!all.media || all.media.length === 0) {
    all.media = [
      { _id: uuid(), id: uuid(), url: "https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?w=800&q=80", name: "linen-stone-residence.jpg", size: 245000, type: "image/jpeg" },
      { _id: uuid(), id: uuid(), url: "https://images.unsplash.com/photo-1497366216548-37526070297c?w=800&q=80", name: "atelier-9-office.jpg", size: 198000, type: "image/jpeg" },
    ];
    console.log("[seed] Created 2 media items");
  }

  // ============= SETTINGS =============
  if (!all.settings) {
    all.settings = getDefaultSettings();
  }

  // ============= THEME =============
  if (!all.theme) {
    all.theme = getDefaultTheme();
  }

  // ============= HEADER/FOOTER =============
  if (!all.headerFooter) {
    all.headerFooter = getDefaultHeaderFooter();
  }

  console.log("[seed] Database seeded successfully");
}
