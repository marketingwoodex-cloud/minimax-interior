/**
 * WP Interior Studio Backend
 * Express + Socket.IO + MongoDB-ready
 *
 * Endpoints:
 *   - POST   /api/auth/login
 *   - POST   /api/auth/logout
 *   - GET    /api/auth/me
 *
 *   - GET    /api/pages
 *   - POST   /api/pages
 *   - GET    /api/pages/:id
 *   - PUT    /api/pages/:id
 *   - DELETE /api/pages/:id
 *   - POST   /api/pages/:id/duplicate
 *   - POST   /api/pages/:id/reorder
 *   - POST   /api/pages/import
 *   - GET    /api/pages/export
 *
 *   - GET    /api/blocks
 *   - POST   /api/blocks
 *   - PUT    /api/blocks/:id
 *   - DELETE /api/blocks/:id
 *
 *   - GET    /api/projects
 *   - POST   /api/projects
 *   - PUT    /api/projects/:id
 *   - DELETE /api/projects/:id
 *
 *   - GET    /api/blog
 *   - POST   /api/blog
 *   - PUT    /api/blog/:id
 *   - DELETE /api/blog/:id
 *
 *   - GET    /api/services
 *   - PUT    /api/services/:id
 *
 *   - GET    /api/media
 *   - POST   /api/media/upload
 *   - DELETE /api/media/:id
 *
 *   - GET    /api/leads
 *   - PUT    /api/leads/:id
 *   - DELETE /api/leads/:id
 *   - POST   /api/leads/:id/notify
 *
 *   - GET    /api/conversations
 *   - POST   /api/conversations
 *   - POST   /api/conversations/:id/messages
 *
 *   - GET    /api/agents
 *   - POST   /api/agents
 *   - PUT    /api/agents/:id
 *   - DELETE /api/agents/:id
 *
 *   - GET    /api/templates
 *   - POST   /api/templates
 *   - DELETE /api/templates/:id
 *
 *   - GET    /api/settings
 *   - PUT    /api/settings
 *   - POST   /api/settings/reset
 *   - POST   /api/settings/import
 *   - GET    /api/settings/export
 *
 *   - GET    /api/theme
 *   - PUT    /api/theme
 *   - POST   /api/theme/reset
 *
 *   - GET    /api/header-footer
 *   - PUT    /api/header-footer
 *
 *   - POST   /api/whatsapp/send
 *   - POST   /api/whatsapp/webhook
 *
 *   - POST   /api/llm/chat
 *   - POST   /api/llm/generate-content
 *
 *   - WebSocket: real-time conversations, presence, builder sync
 */

import express from "express";
import cors from "cors";
import helmet from "helmet";
import morgan from "morgan";
import compression from "compression";
import cookieParser from "cookie-parser";
import rateLimit from "express-rate-limit";
import { createServer } from "http";
import { Server as SocketServer } from "socket.io";
import dotenv from "dotenv";

import { initStore, getStore } from "./store.js";
import { initSocket } from "./socket.js";
import { authRouter } from "./routes/auth.js";
import { pagesRouter } from "./routes/pages.js";
import { blocksRouter } from "./routes/blocks.js";
import { projectsRouter } from "./routes/projects.js";
import { blogRouter } from "./routes/blog.js";
import { servicesRouter } from "./routes/services.js";
import { mediaRouter } from "./routes/media.js";
import { leadsRouter } from "./routes/leads.js";
import { conversationsRouter } from "./routes/conversations.js";
import { agentsRouter } from "./routes/agents.js";
import { templatesRouter } from "./routes/templates.js";
import { settingsRouter } from "./routes/settings.js";
import { themeRouter } from "./routes/theme.js";
import { headerFooterRouter } from "./routes/headerFooter.js";
import { whatsappRouter } from "./routes/whatsapp.js";
import { llmRouter } from "./routes/llm.js";
import { seedDatabase } from "./seed.js";

dotenv.config();

const app = express();
const httpServer = createServer(app);

// ============ MIDDLEWARE ============
app.use(helmet({ contentSecurityPolicy: false }));
app.use(compression());
app.use(cors({
  origin: process.env.CLIENT_ORIGIN || "*",
  credentials: true,
}));
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true, limit: "10mb" }));
app.use(cookieParser());
app.use(morgan(process.env.NODE_ENV === "production" ? "combined" : "dev"));

// Rate limit
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 200,
  standardHeaders: true,
  legacyHeaders: false,
});
app.use("/api/", apiLimiter);

// ============ STATIC FILES (uploads) ============
app.use("/uploads", express.static(process.env.UPLOAD_DIR || "./uploads"));

// ============ SOCKET.IO ============
const io = new SocketServer(httpServer, {
  cors: { origin: process.env.CLIENT_ORIGIN || "*", credentials: true },
});

initSocket(io);

// ============ HEALTH CHECK ============
app.get("/api/health", (_req, res) => {
  res.json({ status: "ok", uptime: process.uptime(), timestamp: new Date().toISOString() });
});

// ============ ROUTES ============
app.use("/api/auth", authRouter);
app.use("/api/pages", pagesRouter);
app.use("/api/blocks", blocksRouter);
app.use("/api/projects", projectsRouter);
app.use("/api/blog", blogRouter);
app.use("/api/services", servicesRouter);
app.use("/api/media", mediaRouter);
app.use("/api/leads", leadsRouter);
app.use("/api/conversations", conversationsRouter);
app.use("/api/agents", agentsRouter);
app.use("/api/templates", templatesRouter);
app.use("/api/settings", settingsRouter);
app.use("/api/theme", themeRouter);
app.use("/api/header-footer", headerFooterRouter);
app.use("/api/whatsapp", whatsappRouter);
app.use("/api/llm", llmRouter);

// ============ ERROR HANDLING ============
app.use((err, _req, res, _next) => {
  console.error("[error]", err);
  res.status(err.status || 500).json({
    error: err.message || "Internal server error",
    ...(process.env.NODE_ENV === "development" && { stack: err.stack }),
  });
});

// 404
app.use((req, res) => {
  res.status(404).json({ error: `Not found: ${req.method} ${req.url}` });
});

// ============ STARTUP ============
const PORT = process.env.PORT || 4000;

async function start() {
  try {
    await initStore();
    await seedDatabase();

    httpServer.listen(PORT, () => {
      console.log(`
╔════════════════════════════════════════╗
║  WP Interior Studio API                ║
║  Running on http://localhost:${PORT}    ║
║  Mode: ${process.env.NODE_ENV || "development"}                    ║
╚════════════════════════════════════════╝
      `);
    });
  } catch (e) {
    console.error("Failed to start server:", e);
    process.exit(1);
  }
}

start();
